import numpy as np
# Importamos SOLO la función que genera el canal, no el simulador entero
from simulator import rc_aggressive_channel 

# 1. Generar los Taps con la MISMA configuración que tienes en simulator.py
# (Copiado de las líneas 142-145 de tu código)
print("Generando canal agresivo...")
H_TAPS = rc_aggressive_channel(
    beta=0.20, 
    span_sym=13, 
    sps=64, 
    frac=0.18,
    echo_a=0.35, 
    echo_d=1, 
    echo_phi=np.pi*0.6, 
    normalize=True
)

print(f"\n--- CANAL GENERADO: {len(H_TAPS)} TAPS ---")
# Imprimimos los valores crudos por si los quieres ver
# print(H_TAPS) 

# 2. Configuración de Punto Fijo (Q9.10)
FRAC_BITS = 10
SCALE     = 2**FRAC_BITS  # 1024

print("\n\n=== COPIA ESTO EN TU complex_fir.v ===")
print(f"// Parametros para complex_fir.v (Formato Q9.10)")
print(f"// Total Taps: {len(H_TAPS)}")

# 3. Generar el código Verilog listo para copiar y pegar
for i, h in enumerate(H_TAPS):
    # Convertir a Q9.10
    val_i = int(round(h.real * SCALE))
    val_q = int(round(h.imag * SCALE))
    
    # Formato Verilog: parameter signed [19:0] H0_I = 20'd819;
    print(f"parameter signed [19:0] H{i}_I = 20'd{val_i}, parameter signed [19:0] H{i}_Q = 20'd{val_q},")

print("\n\n=== COPIA ESTO EN TU gen_chan_vectors.py (Para validar) ===")
# Generamos las listas para Python
real_list = [int(round(h.real * SCALE)) for h in H_TAPS]
imag_list = [int(round(h.imag * SCALE)) for h in H_TAPS]
print(f"H_real = {real_list}")
print(f"H_imag = {imag_list}")