import numpy as np
import matplotlib.pyplot as plt
# Asegúrate de que prbs_qpsk.py esté en la misma carpeta
from prbs_qpsk import prbs_qpsk_iq 

# ==========================================
# 1. CONFIGURACIÓN (AJUSTADA A TU Q9.10)
# ==========================================
N_SYMBOLS = 1000        
SEED_I    = 0x1AA       
SEED_Q    = 0x1FE       
FILE_I    = "tx_ref_i.hex" # Ojo: Verilog leerá 20 bits de acá
FILE_Q    = "tx_ref_q.hex"

# PARÁMETROS DE PUNTO FIJO (Tu FX_NARROW)
FRAC_BITS  = 10   # Q9.10 -> 10 bits fraccionales
TOTAL_BITS = 20   # Ancho total del bus

# Valores esperados en Decimal
# 0.7071 * 2^10 = 724
VAL_POS   = 724
VAL_NEG   = -724

# ==========================================
# 2. GENERACIÓN DE DATOS
# ==========================================
print(f"Generando {N_SYMBOLS} símbolos (Q9.10 - 20 bits)...")
sI, sQ = prbs_qpsk_iq(N_SYMBOLS, seedI=SEED_I, seedQ=SEED_Q)

# Convertir float a enteros para graficar
# Esto es lo que verás en la onda de Vivado (Signed Decimal)
plot_i = np.where(sI > 0, VAL_POS, VAL_NEG)
plot_q = np.where(sQ > 0, VAL_POS, VAL_NEG)

# ==========================================
# 3. GUARDAR ARCHIVOS .HEX (20 Bits)
# ==========================================
def float_to_hex20(val_float):
    # 1. Escalar por 2^10 (Tu formato)
    val_fixed = int(round(val_float * (2**FRAC_BITS)))
    
    # 2. Saturar (Safety) para 20 bits
    max_val = (1 << (TOTAL_BITS - 1)) - 1
    min_val = -(1 << (TOTAL_BITS - 1))
    val_fixed = max(min(val_fixed, max_val), min_val)
    
    # 3. Máscara de 20 bits (0xFFFFF) para el signo
    # Genera strings de 5 caracteres hexa (ej: 002D4)
    return f"{(val_fixed & 0xFFFFF):05X}"

print(f"Guardando archivos...")
with open(FILE_I, 'w') as fI, open(FILE_Q, 'w') as fQ:
    for val_i, val_q in zip(sI, sQ):
        fI.write(float_to_hex20(val_i) + "\n")
        fQ.write(float_to_hex20(val_q) + "\n")

print("¡Listo! Archivos generados.")

# ==========================================
# 4. GRAFICAR (Validación Visual)
# ==========================================
print("Generando gráficos...")

N_PLOT = 50 # Zoom a los primeros 50

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(10, 6))

# Gráfico I
ax1.step(range(N_PLOT), plot_i[:N_PLOT], where='post', color='green', linewidth=2, label='TX I (Esperado)')
ax1.set_ylabel('Amplitud (Entero Q9.10)')
ax1.set_title(f'Señal Esperada en Vivado (Configuración 20 bits)')
ax1.grid(True, linestyle=':', alpha=0.6)
ax1.legend(loc='upper right')
# Líneas de referencia CORREGIDAS
ax1.axhline(y=VAL_POS, color='gray', linestyle='--', alpha=0.5, label=f'+{VAL_POS}')
ax1.axhline(y=VAL_NEG, color='gray', linestyle='--', alpha=0.5, label=f'{VAL_NEG}')
# Ajustamos la escala vertical para que se vea bien el 724
ax1.set_ylim(-1000, 1000)

# Gráfico Q
ax2.step(range(N_PLOT), plot_q[:N_PLOT], where='post', color='blue', linewidth=2, label='TX Q (Esperado)')
ax2.set_ylabel('Amplitud (Entero Q9.10)')
ax2.set_xlabel('Número de Símbolo')
ax2.grid(True, linestyle=':', alpha=0.6)
ax2.legend(loc='upper right')
ax2.axhline(y=VAL_POS, color='gray', linestyle='--', alpha=0.5)
ax2.axhline(y=VAL_NEG, color='gray', linestyle='--', alpha=0.5)
ax2.set_ylim(-1000, 1000)

plt.tight_layout()
plt.show()